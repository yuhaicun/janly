Documentation in <https://github.com/codeskyblue/atx-uiautomator>
