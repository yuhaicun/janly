# jenkinsdemo
用于测试jenkins持续构建服务
